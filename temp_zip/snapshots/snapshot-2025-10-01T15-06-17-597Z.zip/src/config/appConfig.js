export const AI_RECEPTIONIST_PHONE = "";
