import React from 'react';
export default function Bulk() {
  return <div>Bulk Actions (Placeholder)</div>;
}
