import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ChevronRight, Send, FileText, User, CreditCard, AlertCircle, X } from 'lucide-react';

// Bureau contacts data
const bureauContacts = {
  experian: {
    name: 'Experian',
    faxPrimary: '+19727903901',
    faxBackup: '+14698143570',
    disputeAddress: {
      name: 'Experian Dispute Department',
      street: 'P.O. Box 4000',
      city: 'Allen',
      state: 'TX',
      zip: '75013'
    }
  },
  equifax: {
    name: 'Equifax',
    faxPrimary: '+14048851000',
    faxBackup: '+14048851001',
    disputeAddress: {
      name: 'Equifax Dispute Department',
      street: 'P.O. Box 740256',
      city: 'Atlanta',
      state: 'GA',
      zip: '30374-0256'
    }
  },
  transunion: {
    name: 'TransUnion',
    faxPrimary: '+16109465698',
    faxBackup: '+16104558789',
    disputeAddress: {
      name: 'TransUnion Dispute Department',
      street: 'P.O. Box 2000',
      city: 'Chester',
      state: 'PA',
      zip: '19016'
    }
  }
};

// Letter generation function
const generateDisputeLetter = (letterType, data) => {
  const { clientInfo, disputeItems, bureau } = data;
  const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  
  if (letterType === 'initial') {
    return `${date}

${clientInfo.fullName}
${clientInfo.address}
${clientInfo.city}, ${clientInfo.state} ${clientInfo.zip}
SSN: XXX-XX-${clientInfo.ssnLast4 || 'XXXX'}
DOB: ${clientInfo.dateOfBirth || 'XX/XX/XXXX'}

${bureau.name}
${bureau.disputeAddress.street}
${bureau.disputeAddress.city}, ${bureau.disputeAddress.state} ${bureau.disputeAddress.zip}

RE: Request for Investigation of Inaccurate Information

To Whom It May Concern:

I am writing to dispute the following inaccurate information in my credit report.

The following accounts are inaccurate:

${disputeItems.map((item, index) => `
${index + 1}. Account: ${item.creditor}
   Account Number: ${item.accountNumber}
   Reason: ${item.reason}
   Details: ${item.details || 'This account is not mine.'}
`).join('')}

Under the Fair Credit Reporting Act (FCRA), Section 611, I am requesting that you investigate these items within 30 days.

Sincerely,

${clientInfo.fullName}`;
  }
  
  return 'Letter template not available';
};

function DisputeCreation() {
  const [step, setStep] = useState(1);
  const [clients, setClients] = useState([]);
  const [filteredClients, setFilteredClients] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState(null);
  const [disputeItems, setDisputeItems] = useState([]);
  const [selectedBureaus, setSelectedBureaus] = useState([]);
  const [letterType, setLetterType] = useState('initial');
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState('');

  // Load clients on mount
  useEffect(() => {
    loadClients();
  }, []);

  // Filter clients based on search
  useEffect(() => {
    const filtered = clients.filter(client => {
      const fullName = `${client.firstName || ''} ${client.lastName || ''}`.toLowerCase();
      const email = (client.email || '').toLowerCase();
      const search = searchTerm.toLowerCase();
      return fullName.includes(search) || email.includes(search);
    });
    setFilteredClients(filtered);
  }, [searchTerm, clients]);

  const loadClients = async () => {
    try {
      const clientsQuery = query(collection(db, 'contacts'));
      const snapshot = await getDocs(clientsQuery);
      const clientList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setClients(clientList);
      setFilteredClients(clientList);
    } catch (error) {
      console.error('Error loading clients:', error);
      // Use mock data if database fails
      const mockClients = [
        {
          id: '1',
          firstName: 'John',
          lastName: 'Smith',
          email: 'john@email.com',
          phone: '555-0100'
        }
      ];
      setClients(mockClients);
      setFilteredClients(mockClients);
    }
  };

  const addDisputeItem = () => {
    setDisputeItems([...disputeItems, {
      id: Date.now(),
      creditor: '',
      accountNumber: '',
      reason: 'Not mine',
      details: ''
    }]);
  };

  const updateDisputeItem = (id, field, value) => {
    setDisputeItems(items =>
      items.map(item =>
        item.id === id ? { ...item, [field]: value } : item
      )
    );
  };

  const removeDisputeItem = (id) => {
    setDisputeItems(items => items.filter(item => item.id !== id));
  };

  const generatePreview = () => {
    if (!selectedClient || disputeItems.length === 0 || selectedBureaus.length === 0) return;

    const clientInfo = {
      fullName: `${selectedClient.firstName || ''} ${selectedClient.lastName || ''}`,
      address: selectedClient.address || '123 Main St',
      city: selectedClient.city || 'City',
      state: selectedClient.state || 'CA',
      zip: selectedClient.zip || '12345',
      ssnLast4: selectedClient.ssnLast4,
      dateOfBirth: selectedClient.dateOfBirth
    };

    const bureau = bureauContacts[selectedBureaus[0].toLowerCase()];
    const letterContent = generateDisputeLetter(letterType, {
      clientInfo,
      disputeItems,
      bureau
    });

    setPreview(letterContent);
  };

  const sendDisputes = async () => {
    setLoading(true);
    try {
      const disputeRecord = {
        clientId: selectedClient.id,
        clientName: `${selectedClient.firstName || ''} ${selectedClient.lastName || ''}`,
        items: disputeItems,
        bureaus: selectedBureaus,
        letterType,
        status: 'pending_send',
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'disputes'), disputeRecord);
      alert('Dispute letters created successfully!');
      
      // Reset form
      setStep(1);
      setSelectedClient(null);
      setDisputeItems([]);
      setSelectedBureaus([]);
      setPreview('');
    } catch (error) {
      console.error('Error creating dispute:', error);
      alert('Error creating dispute. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Create Dispute Letters</h1>
      
      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-between max-w-3xl">
          <div className={`flex items-center ${step >= 1 ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`rounded-full p-2 ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
              <User className="w-5 h-5" />
            </div>
            <span className="ml-2 font-medium hidden sm:inline">Select Client</span>
          </div>
          <ChevronRight className="text-gray-400 mx-2" />
          <div className={`flex items-center ${step >= 2 ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`rounded-full p-2 ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
              <CreditCard className="w-5 h-5" />
            </div>
            <span className="ml-2 font-medium hidden sm:inline">Add Items</span>
          </div>
          <ChevronRight className="text-gray-400 mx-2" />
          <div className={`flex items-center ${step >= 3 ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`rounded-full p-2 ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
              <FileText className="w-5 h-5" />
            </div>
            <span className="ml-2 font-medium hidden sm:inline">Review & Send</span>
          </div>
        </div>
      </div>

      {/* Step 1: Client Selection */}
      {step === 1 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold mb-4">Select Client</h2>
          <input
            type="text"
            placeholder="Search clients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg mb-4"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
            {filteredClients.map(client => (
              <div
                key={client.id}
                onClick={() => setSelectedClient(client)}
                className={`p-4 border rounded-lg cursor-pointer ${
                  selectedClient?.id === client.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <h3 className="font-semibold">{client.firstName} {client.lastName}</h3>
                <p className="text-sm text-gray-600">{client.email}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-end">
            <button
              onClick={() => setStep(2)}
              disabled={!selectedClient}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg disabled:bg-gray-300"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Dispute Items */}
      {step === 2 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold mb-4">Add Dispute Items</h2>
          
          {disputeItems.map((item, index) => (
            <div key={item.id} className="mb-4 p-4 border rounded-lg">
              <div className="flex justify-between mb-3">
                <h4 className="font-semibold">Item #{index + 1}</h4>
                <button
                  onClick={() => removeDisputeItem(item.id)}
                  className="text-red-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Creditor Name"
                  value={item.creditor}
                  onChange={(e) => updateDisputeItem(item.id, 'creditor', e.target.value)}
                  className="px-3 py-2 border rounded"
                />
                <input
                  type="text"
                  placeholder="Account Number"
                  value={item.accountNumber}
                  onChange={(e) => updateDisputeItem(item.id, 'accountNumber', e.target.value)}
                  className="px-3 py-2 border rounded"
                />
                <select
                  value={item.reason}
                  onChange={(e) => updateDisputeItem(item.id, 'reason', e.target.value)}
                  className="px-3 py-2 border rounded"
                >
                  <option value="Not mine">Not mine</option>
                  <option value="Never late">Never late</option>
                  <option value="Paid in full">Paid in full</option>
                  <option value="Incorrect balance">Incorrect balance</option>
                  <option value="Identity theft">Identity theft</option>
                </select>
              </div>
            </div>
          ))}

          <button
            onClick={addDisputeItem}
            className="mb-6 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg w-full"
          >
            + Add Dispute Item
          </button>

          <div className="mb-6">
            <h3 className="font-semibold mb-3">Select Bureaus</h3>
            <div className="flex gap-4">
              {['Experian', 'Equifax', 'TransUnion'].map(bureau => (
                <label key={bureau} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedBureaus.includes(bureau)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedBureaus([...selectedBureaus, bureau]);
                      } else {
                        setSelectedBureaus(selectedBureaus.filter(b => b !== bureau));
                      }
                    }}
                    className="mr-2"
                  />
                  {bureau}
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-between">
            <button onClick={() => setStep(1)} className="px-6 py-2 border rounded-lg">
              Back
            </button>
            <button
              onClick={() => {
                generatePreview();
                setStep(3);
              }}
              disabled={disputeItems.length === 0 || selectedBureaus.length === 0}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg disabled:bg-gray-300"
            >
              Preview
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Review and Send */}
      {step === 3 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold mb-4">Review and Send</h2>
          
          <div className="mb-6">
            <h3 className="font-semibold mb-3">Letter Preview</h3>
            <div className="bg-gray-50 p-4 rounded-lg max-h-96 overflow-y-auto">
              <pre className="whitespace-pre-wrap text-sm">{preview}</pre>
            </div>
          </div>

          <div className="flex justify-between">
            <button onClick={() => setStep(2)} className="px-6 py-2 border rounded-lg">
              Back
            </button>
            <button
              onClick={sendDisputes}
              disabled={loading}
              className="px-6 py-2 bg-green-600 text-white rounded-lg disabled:bg-gray-300"
            >
              {loading ? 'Sending...' : 'Send Disputes'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default DisputeCreation;