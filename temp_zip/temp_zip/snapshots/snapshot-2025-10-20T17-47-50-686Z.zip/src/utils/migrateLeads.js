// Re-export the single source of truth; no initialization here.
export * from "../lib/firebase";
