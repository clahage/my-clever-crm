import React from 'react';
import DisputeTracker from '../../components/DisputeTracker';

const ClientDisputes = () => {
  return <DisputeTracker />;
};

export default ClientDisputes;
