import React from "react";

export default function Home() {
  return (
    <div style={{ padding: 24, fontFamily: "system-ui" }}>
      <h1>Home</h1>
      <p>Protected home page.</p>
    </div>
  );
}
