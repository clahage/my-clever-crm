// Canonical re-exports so old imports keep working
export * from '@/auth/AuthProvider.jsx';
export { default as AuthProvider } from '@/auth/AuthProvider.jsx';
