import React from 'react';

function TestAnalytics() {
  return <div>TEST COMPONENT LOADED</div>;
}

export default TestAnalytics;
