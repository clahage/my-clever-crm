// openaiConfig.js is deprecated.
// All OpenAI usage has been migrated to the secure aiService at '@/services/aiService'.
// Please import aiService and call its methods (complete, analyzeCreditReport, parseCreditReport, generateDisputeLetter, etc.)
// Example:
// import aiService from '@/services/aiService';
// const res = await aiService.complete({ messages: [...] });

export default null;
