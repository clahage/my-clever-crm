import React from 'react';
export default function Automation() {
  return <div>Automation Rules (Placeholder)</div>;
}
