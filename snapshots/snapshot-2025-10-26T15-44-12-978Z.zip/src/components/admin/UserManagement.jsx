import React from 'react';

const UserManagement = () => {
  return (
    <div>
      <h2>User Management</h2>
      {/* User list, add/edit/delete users, assign roles */}
    </div>
  );
};

export default UserManagement;
