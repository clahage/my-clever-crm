import React from "react";

export default function Documents() {
  return (
    <div className="space-y-2">
      <h1 className="text-2xl font-semibold">Documents</h1>
      <p className="text-sm opacity-80">
        Placeholder screen. Replace this with the real Documents view.
      </p>
    </div>
  );
}
