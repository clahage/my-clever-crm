import React from 'react';
import Leads from '@/components/Leads';

const Contacts = () => {
  // The Contacts page now uses the enterprise-grade Leads component for UI and logic
  return <Leads />;
}

export default Contacts;